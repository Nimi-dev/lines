# Deploying lines (PWA) — phone-only, ~15 minutes

## First deploy
1. Create a free account at dash.cloudflare.com (Safari on your phone is fine).
2. Dashboard -> Workers & Pages -> Create -> Pages -> "Upload assets" (Direct Upload).
3. Project name: `lines` (URL becomes https://lines.pages.dev — pick another if taken).
4. Upload this zip (or the extracted files). Deploy. Live in ~1 minute.

## Install on your phone
5. Open the URL in Safari -> Share -> Add to Home Screen. Real standalone app: icon, splash, offline.
6. Open it -> Daily gauntlet -> "Restore" -> paste your training-log export -> Apply. History migrated.

## Updates
- New zip from Claude -> same project -> "Create new deployment" -> upload. Live in a minute.
- Every deployment is kept; instant rollback from the Deployments tab if anything is off.

## Notes
- Footer shows the build version (v6.2 · pwa). Verify after every deploy.
- App works fully offline after first load (service worker caches everything).
- Engine: tries real Stockfish from CDN first (a normal browser may allow it — watch for "SF" vs "eng" on the eval bar), falls back to the built-in engine.
- Custom domain later: Pages project -> Custom domains -> add. Nothing else changes.
